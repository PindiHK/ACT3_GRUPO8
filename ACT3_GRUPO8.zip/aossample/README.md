# Proyecto FastAPI - Práctica Arquitectura Orientada a Servicios

## Descripción del Proyecto

Hemos desarrollado una **API REST utilizando FastAPI**, un framework moderno y de alto rendimiento para Python. Este proyecto está organizado siguiendo las mejores prácticas de arquitectura de software, con una estructura modular que facilita el mantenimiento y la escalabilidad.

Nuestro proyecto incluye endpoints para realizar operaciones básicas como sumas, concatenación de cadenas y cálculo de longitudes. Está completamente preparado para desplegarse tanto en entornos locales como en la nube, específicamente en instancias AWS EC2.

## Estructura del Proyecto

```
aossample/
│
├── app/
│   ├── __init__.py              # Inicializa el paquete app
│   ├── main.py                  # Punto de entrada de la aplicación
│   ├── routes/
│   │   ├── __init__.py
│   │   └── sample.py            # Define los endpoints de la API
│   ├── models/
│   │   ├── __init__.py
│   │   └── item.py              # Modelos de datos con Pydantic
│   ├── tests/
│   │   ├── __init__.py
│   │   └── test_sample.py       # Tests unitarios
│   └── requirements.txt         # Dependencias del proyecto
└── README.md                    # Documentación (este archivo)
```

## Instalación y Configuración

### Requisitos Previos

- Python 3.8 o superior
- pip (gestor de paquetes de Python)
- Git (opcional, para clonar el repositorio)

### Paso 1: Obtener el Proyecto

Si tienes el proyecto comprimido:
```bash
unzip ACT3_GRUPO8.zip
cd aossample
```

Si prefieres clonarlo desde GitHub:
```bash
git clone https://github.com/Jordi085/aossample.git
cd aossample
```

### Paso 2: Crear el Entorno Virtual

Creamos un entorno virtual para aislar las dependencias de nuestro proyecto:

**En Linux/macOS:**
```bash
python3 -m venv venv
source venv/bin/activate
```

**En Windows:**
```cmd
python -m venv venv
venv\Scripts\activate
```

Verás que tu terminal ahora muestra `(venv)` al principio, indicando que el entorno virtual está activo.

### Paso 3: Instalar las Dependencias

Una vez activado el entorno virtual, instalamos todas las librerías necesarias:

```bash
pip install -r app/requirements.txt
```

Este comando instalará:
- **FastAPI**: Framework web para crear la API
- **Uvicorn**: Servidor ASGI para ejecutar FastAPI
- **Pytest**: Framework para ejecutar tests
- **HTTPx**: Cliente HTTP para los tests
- **Pydantic**: Validación de datos

### Paso 4: Ejecutar la Aplicación

Ahora ejecutamos nuestra API:

```bash
uvicorn app.main:app --reload
```

El parámetro `--reload` hace que el servidor se reinicie automáticamente cuando detecta cambios en el código, muy útil durante el desarrollo.

Verás un mensaje similar a:
```
INFO:     Uvicorn running on http://127.0.0.1:8000 (Press CTRL+C to quit)
INFO:     Started reloader process
INFO:     Started server process
INFO:     Waiting for application startup.
INFO:     Application startup complete.
```

¡Perfecto! Nuestra API ya está funcionando.

### Paso 5: Acceder a la Documentación Interactiva

FastAPI genera automáticamente documentación interactiva para nuestra API. Podemos acceder a ella en:

- **Swagger UI**: http://127.0.0.1:8000/docs
- **ReDoc**: http://127.0.0.1:8000/redoc

Desde Swagger UI podemos probar todos los endpoints directamente desde el navegador.

## Endpoints Disponibles

### 1. Endpoint Raíz
- **Método**: GET
- **URL**: `/`
- **Descripción**: Mensaje de bienvenida
- **Respuesta**:
```json
{
  "message": "Welcome to FastAPI Sample Project"
}
```

### 2. Procesar Datos (POST)
- **Método**: POST
- **URL**: `/process`
- **Descripción**: Recibe dos números enteros y devuelve su suma
- **Ejemplo de solicitud**:
```json
{
  "value1": 10,
  "value2": 5
}
```
- **Respuesta**:
```json
{
  "result": 15
}
```

### 3. Concatenar Cadenas (GET)
- **Método**: GET
- **URL**: `/concat`
- **Parámetros**: 
  - `param1`: Primera cadena
  - `param2`: Segunda cadena
- **Ejemplo**: `/concat?param1=Hola&param2=Mundo`
- **Respuesta**:
```json
{
  "result": "HolaMundo"
}
```

### 4. Longitud de Cadena (GET)
- **Método**: GET
- **URL**: `/length`
- **Parámetros**: 
  - `string`: Cadena a medir
- **Ejemplo**: `/length?string=FastAPI`
- **Respuesta**:
```json
{
  "length": 7
}
```

## Ejecutar Tests

Hemos incluido tests unitarios para verificar que todos los endpoints funcionan correctamente. Para ejecutarlos:

```bash
python -m pytest
```

Deberías ver algo como:
```
============================= test session starts ==============================
collected 4 items

app/tests/test_sample.py ....                                            [100%]

============================== 4 passed in 0.15s ===============================
```

Los cuatro tests verifican:
1. El endpoint raíz
2. El procesamiento de datos (POST)
3. La concatenación de cadenas
4. El cálculo de longitud

## Despliegue en AWS EC2

Para desplegar esta aplicación en una instancia EC2:

1. **Conectarse a la instancia EC2**:
```bash
ssh -i tu-clave.pem ec2-user@tu-ip-publica
```

2. **Instalar Python y dependencias**:
```bash
sudo yum update -y
sudo yum install python3 python3-pip git -y
```

3. **Clonar el proyecto y configurar**:
```bash
git clone https://github.com/Jordi085/aossample.git
cd aossample
python3 -m venv venv
source venv/bin/activate
pip install -r app/requirements.txt
```

4. **Ejecutar la aplicación**:
```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

5. **Configurar el Security Group** en AWS para permitir tráfico en el puerto 8000.

## Notas Importantes

- **Entorno Virtual**: Siempre recomendamos usar un entorno virtual para evitar conflictos entre dependencias de diferentes proyectos.

- **Modo Desarrollo vs Producción**: El flag `--reload` solo debe usarse en desarrollo. En producción, ejecuta sin este parámetro.

- **Actualizar Dependencias**: Si instalas nuevas librerías, actualiza `requirements.txt`:
```bash
pip freeze > app/requirements.txt
```

- **Puerto Ocupado**: Si el puerto 8000 está en uso, puedes especificar otro:
```bash
uvicorn app.main:app --reload --port 8001
```

## Solución de Problemas

### Error: "Module not found"
Asegúrate de que el entorno virtual está activado y las dependencias instaladas:
```bash
source venv/bin/activate  # Linux/macOS
pip install -r app/requirements.txt
```

### Error: "Address already in use"
Otro proceso está usando el puerto 8000. Cierra ese proceso o usa otro puerto:
```bash
uvicorn app.main:app --reload --port 8001
```

### Tests fallan
Verifica que todas las dependencias están instaladas correctamente y que estás ejecutando pytest desde la raíz del proyecto.

## Contribuciones

Si encuentras algún error o tienes sugerencias para mejorar el proyecto, no dudes en abrir un issue o crear un pull request en el repositorio de GitHub.

## Licencia

Este proyecto ha sido desarrollado con fines educativos para la asignatura de Arquitectura Orientada a Servicios.

---

**¡Esperamos que este proyecto sea fácil de entender, ejecutar y desplegar! Si tienes cualquier duda, no dudes en contactarnos.**
