from pydantic import BaseModel

class Item(BaseModel):
    value1: int
    value2: int
