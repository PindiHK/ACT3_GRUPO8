from fastapi import FastAPI
from app.routes import sample

app = FastAPI()

# Include routes
app.include_router(sample.router)

@app.get("/")
def read_root():
    return {"message": "Welcome to FastAPI Sample Project"}
