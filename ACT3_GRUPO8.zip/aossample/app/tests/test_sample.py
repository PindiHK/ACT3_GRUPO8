from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_read_root():
    response = client.get("/")
    assert response.status_code == 200
    assert response.json() == {"message": "Welcome to FastAPI Sample Project"}

def test_process_item():
    response = client.post(
        "/process",
        json={"value1": 10, "value2": 5}
    )
    assert response.status_code == 200
    assert response.json() == {"result": 15}

def test_concat_strings():
    response = client.get("/concat?param1=Hello&param2=World")
    assert response.status_code == 200
    assert response.json() == {"result": "HelloWorld"}

def test_string_length():
    response = client.get("/length?string=FastAPI")
    assert response.status_code == 200
    assert response.json() == {"length": 7}
