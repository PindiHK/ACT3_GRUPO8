from fastapi import APIRouter
from app.models.item import Item

router = APIRouter()

@router.post("/process")
def process_item(item: Item):
    """
    Endpoint POST que recibe dos valores enteros y devuelve su suma
    """
    result = item.value1 + item.value2
    return {"result": result}

@router.get("/concat")
def concat_strings(param1: str, param2: str):
    """
    Endpoint GET que concatena dos strings recibidos como parámetros
    """
    return {"result": param1 + param2}

@router.get("/length")
def string_length(string: str):
    """
    Endpoint GET que devuelve la longitud de un string
    """
    return {"length": len(string)}
